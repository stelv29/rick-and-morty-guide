# Rick and Morty Guide (gabarito)

App React Native (Expo SDK 57) da aula 08 do Prof. Rodrigo Gomide + Exercício 6.
Use só para comparar com o seu código.

    npm install
    npm run web
